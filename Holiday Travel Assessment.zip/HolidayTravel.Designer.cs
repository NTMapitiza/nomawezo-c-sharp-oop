﻿namespace HolidayDatabase
{
    partial class frmHoliday
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label holidayNoLabel;
            System.Windows.Forms.Label destinationLabel;
            System.Windows.Forms.Label costLabel;
            System.Windows.Forms.Label departureDateLabel;
            System.Windows.Forms.Label noOfDaysLabel;
            System.Windows.Forms.Label availableLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHoliday));
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.btnLastRow = new System.Windows.Forms.Button();
            this.btnNextRow = new System.Windows.Forms.Button();
            this.btnPreviousRow = new System.Windows.Forms.Button();
            this.btnFirstRow = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.travelDBDataSet = new HolidayDatabase.TravelDBDataSet();
            this.tblHolidayBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblHolidayTableAdapter = new HolidayDatabase.TravelDBDataSetTableAdapters.tblHolidayTableAdapter();
            this.tableAdapterManager = new HolidayDatabase.TravelDBDataSetTableAdapters.TableAdapterManager();
            this.txtHolidayNo = new System.Windows.Forms.TextBox();
            this.txtDestination = new System.Windows.Forms.TextBox();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.txtDepartureDate = new System.Windows.Forms.TextBox();
            this.txtNoOfDays = new System.Windows.Forms.TextBox();
            this.chkAvailable = new System.Windows.Forms.CheckBox();
            holidayNoLabel = new System.Windows.Forms.Label();
            destinationLabel = new System.Windows.Forms.Label();
            costLabel = new System.Windows.Forms.Label();
            departureDateLabel = new System.Windows.Forms.Label();
            noOfDaysLabel = new System.Windows.Forms.Label();
            availableLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.travelDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblHolidayBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // holidayNoLabel
            // 
            holidayNoLabel.AutoSize = true;
            holidayNoLabel.Location = new System.Drawing.Point(15, 145);
            holidayNoLabel.Name = "holidayNoLabel";
            holidayNoLabel.Size = new System.Drawing.Size(107, 17);
            holidayNoLabel.TabIndex = 16;
            holidayNoLabel.Text = "Holiday number";
            // 
            // destinationLabel
            // 
            destinationLabel.AutoSize = true;
            destinationLabel.Location = new System.Drawing.Point(15, 173);
            destinationLabel.Name = "destinationLabel";
            destinationLabel.Size = new System.Drawing.Size(79, 17);
            destinationLabel.TabIndex = 17;
            destinationLabel.Text = "Destination";
            // 
            // costLabel
            // 
            costLabel.AutoSize = true;
            costLabel.Location = new System.Drawing.Point(15, 201);
            costLabel.Name = "costLabel";
            costLabel.Size = new System.Drawing.Size(36, 17);
            costLabel.TabIndex = 18;
            costLabel.Text = "Cost";
            // 
            // departureDateLabel
            // 
            departureDateLabel.AutoSize = true;
            departureDateLabel.Location = new System.Drawing.Point(15, 229);
            departureDateLabel.Name = "departureDateLabel";
            departureDateLabel.Size = new System.Drawing.Size(106, 17);
            departureDateLabel.TabIndex = 19;
            departureDateLabel.Text = "Departure Date";
            // 
            // noOfDaysLabel
            // 
            noOfDaysLabel.AutoSize = true;
            noOfDaysLabel.Location = new System.Drawing.Point(15, 257);
            noOfDaysLabel.Name = "noOfDaysLabel";
            noOfDaysLabel.Size = new System.Drawing.Size(81, 17);
            noOfDaysLabel.TabIndex = 20;
            noOfDaysLabel.Text = "No Of Days";
            // 
            // availableLabel
            // 
            availableLabel.AutoSize = true;
            availableLabel.Location = new System.Drawing.Point(15, 287);
            availableLabel.Name = "availableLabel";
            availableLabel.Size = new System.Drawing.Size(65, 17);
            availableLabel.TabIndex = 21;
            availableLabel.Text = "Available";
            // 
            // txtPosition
            // 
            this.txtPosition.Enabled = false;
            this.txtPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosition.Location = new System.Drawing.Point(166, 349);
            this.txtPosition.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(90, 27);
            this.txtPosition.TabIndex = 23;
            this.txtPosition.TabStop = false;
            this.txtPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnLastRow
            // 
            this.btnLastRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLastRow.Location = new System.Drawing.Point(332, 343);
            this.btnLastRow.Margin = new System.Windows.Forms.Padding(4);
            this.btnLastRow.Name = "btnLastRow";
            this.btnLastRow.Size = new System.Drawing.Size(80, 41);
            this.btnLastRow.TabIndex = 9;
            this.btnLastRow.Text = ">>";
            this.btnLastRow.UseVisualStyleBackColor = true;
            this.btnLastRow.Click += new System.EventHandler(this.btnLastRow_Click);
            // 
            // btnNextRow
            // 
            this.btnNextRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextRow.Location = new System.Drawing.Point(256, 343);
            this.btnNextRow.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextRow.Name = "btnNextRow";
            this.btnNextRow.Size = new System.Drawing.Size(80, 41);
            this.btnNextRow.TabIndex = 8;
            this.btnNextRow.Text = ">";
            this.btnNextRow.UseVisualStyleBackColor = true;
            this.btnNextRow.Click += new System.EventHandler(this.btnNextRow_Click);
            // 
            // btnPreviousRow
            // 
            this.btnPreviousRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreviousRow.Location = new System.Drawing.Point(85, 343);
            this.btnPreviousRow.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreviousRow.Name = "btnPreviousRow";
            this.btnPreviousRow.Size = new System.Drawing.Size(80, 41);
            this.btnPreviousRow.TabIndex = 7;
            this.btnPreviousRow.Text = "<";
            this.btnPreviousRow.UseVisualStyleBackColor = true;
            this.btnPreviousRow.Click += new System.EventHandler(this.btnPreviousRow_Click);
            // 
            // btnFirstRow
            // 
            this.btnFirstRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirstRow.Location = new System.Drawing.Point(8, 343);
            this.btnFirstRow.Margin = new System.Windows.Forms.Padding(4);
            this.btnFirstRow.Name = "btnFirstRow";
            this.btnFirstRow.Size = new System.Drawing.Size(80, 41);
            this.btnFirstRow.TabIndex = 6;
            this.btnFirstRow.Text = "<<";
            this.btnFirstRow.UseVisualStyleBackColor = true;
            this.btnFirstRow.Click += new System.EventHandler(this.btnFirstRow_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(463, 343);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(127, 41);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(463, 302);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(127, 41);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(463, 261);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(127, 41);
            this.btnPrint.TabIndex = 13;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(463, 220);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(127, 41);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(463, 179);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(127, 41);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(463, 138);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(127, 41);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(142, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 40);
            this.label1.TabIndex = 22;
            this.label1.Text = "Downton Travel";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(463, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 119);
            this.pictureBox1.TabIndex = 47;
            this.pictureBox1.TabStop = false;
            // 
            // travelDBDataSet
            // 
            this.travelDBDataSet.DataSetName = "TravelDBDataSet";
            this.travelDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblHolidayBindingSource
            // 
            this.tblHolidayBindingSource.DataMember = "tblHoliday";
            this.tblHolidayBindingSource.DataSource = this.travelDBDataSet;
            // 
            // tblHolidayTableAdapter
            // 
            this.tblHolidayTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tblHolidayTableAdapter = this.tblHolidayTableAdapter;
            this.tableAdapterManager.UpdateOrder = HolidayDatabase.TravelDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // txtHolidayNo
            // 
            this.txtHolidayNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblHolidayBindingSource, "HolidayNo", true));
            this.txtHolidayNo.Location = new System.Drawing.Point(131, 142);
            this.txtHolidayNo.Name = "txtHolidayNo";
            this.txtHolidayNo.Size = new System.Drawing.Size(104, 22);
            this.txtHolidayNo.TabIndex = 0;
            // 
            // txtDestination
            // 
            this.txtDestination.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblHolidayBindingSource, "Destination", true));
            this.txtDestination.Location = new System.Drawing.Point(131, 170);
            this.txtDestination.Name = "txtDestination";
            this.txtDestination.Size = new System.Drawing.Size(104, 22);
            this.txtDestination.TabIndex = 1;
            // 
            // txtCost
            // 
            this.txtCost.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblHolidayBindingSource, "Cost", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "C2"));
            this.txtCost.Location = new System.Drawing.Point(131, 198);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(104, 22);
            this.txtCost.TabIndex = 2;
            this.txtCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDepartureDate
            // 
            this.txtDepartureDate.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblHolidayBindingSource, "DepartureDate", true));
            this.txtDepartureDate.Location = new System.Drawing.Point(131, 226);
            this.txtDepartureDate.Name = "txtDepartureDate";
            this.txtDepartureDate.Size = new System.Drawing.Size(104, 22);
            this.txtDepartureDate.TabIndex = 3;
            // 
            // txtNoOfDays
            // 
            this.txtNoOfDays.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblHolidayBindingSource, "NoOfDays", true));
            this.txtNoOfDays.Location = new System.Drawing.Point(131, 254);
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.Size = new System.Drawing.Size(104, 22);
            this.txtNoOfDays.TabIndex = 4;
            // 
            // chkAvailable
            // 
            this.chkAvailable.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tblHolidayBindingSource, "Available", true));
            this.chkAvailable.Location = new System.Drawing.Point(131, 282);
            this.chkAvailable.Name = "chkAvailable";
            this.chkAvailable.Size = new System.Drawing.Size(104, 24);
            this.chkAvailable.TabIndex = 5;
            this.chkAvailable.UseVisualStyleBackColor = true;
            // 
            // frmHoliday
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(629, 411);
            this.Controls.Add(holidayNoLabel);
            this.Controls.Add(this.txtHolidayNo);
            this.Controls.Add(destinationLabel);
            this.Controls.Add(this.txtDestination);
            this.Controls.Add(costLabel);
            this.Controls.Add(this.txtCost);
            this.Controls.Add(departureDateLabel);
            this.Controls.Add(this.txtDepartureDate);
            this.Controls.Add(noOfDaysLabel);
            this.Controls.Add(this.txtNoOfDays);
            this.Controls.Add(availableLabel);
            this.Controls.Add(this.chkAvailable);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtPosition);
            this.Controls.Add(this.btnLastRow);
            this.Controls.Add(this.btnNextRow);
            this.Controls.Add(this.btnPreviousRow);
            this.Controls.Add(this.btnFirstRow);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmHoliday";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Task A Nomawezo Mapitiza 22/06/2020";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.travelDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblHolidayBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.Button btnLastRow;
        private System.Windows.Forms.Button btnNextRow;
        private System.Windows.Forms.Button btnPreviousRow;
        private System.Windows.Forms.Button btnFirstRow;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private TravelDBDataSet travelDBDataSet;
        private System.Windows.Forms.BindingSource tblHolidayBindingSource;
        private TravelDBDataSetTableAdapters.tblHolidayTableAdapter tblHolidayTableAdapter;
        private TravelDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox txtHolidayNo;
        private System.Windows.Forms.TextBox txtDestination;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.TextBox txtDepartureDate;
        private System.Windows.Forms.TextBox txtNoOfDays;
        private System.Windows.Forms.CheckBox chkAvailable;
    }
}

